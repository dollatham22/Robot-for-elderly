import tkinter
import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
from tkinter import font  as tkfont
import mysql.connector
from tkinter.messagebox import showinfo
from datetime import datetime
import time
import serial
import RPi.GPIO as GPIO
from time import sleep
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import webbrowser
import pygame

DT =31
SCK=29
sample=0

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(29, GPIO.OUT)

def readCount():
  i=0
  Count=0
  GPIO.setwarnings(False)
  GPIO.setmode(GPIO.BOARD)
  GPIO.setup(29, GPIO.OUT)
  GPIO.setup(31, GPIO.OUT)
  GPIO.output(29,1)
  GPIO.output(29,0)
  GPIO.setup(31, GPIO.IN)

  while GPIO.input(31) == 1:
      i=0
  for i in range(24):
        GPIO.output(29,1)
        Count=Count<<1

        GPIO.output(29,0)
        #time.sleep(0.001)
        if GPIO.input(31) == 0: 
            Count=Count+1
            #print Count
        
  GPIO.output(29,1)
  Count=Count^0x800000
  #time.sleep(0.001)
  GPIO.output(29,0)
  return Count

cred = credentials.Certificate('./video-meeting-5fccc-firebase-adminsdk-f4zug-907c6ea812.json')
firebase_admin.initialize_app(cred, {'databaseURL': 'https://video-meeting-5fccc-default-rtdb.firebaseio.com/'})

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="12345678",
  database="robot_for_elderly"
)


mycursor = mydb.cursor()
mycursor.execute("SELECT time FROM timealert")
myresult = mycursor.fetchall()

#now = datetime.now()
#current_time = now.strftime("%H:%M")
#class Alert:
 #   def fallalert():
  #      ser = serial.Serial('/dev/ttyUSB0',9600)
  #      read_serial_falldetec=ser.readline()
   #     print(read_serial_falldetec)
        

class Clock:
    def __init__(self):
        self.time1 = ''
        self.time2 = time.strftime('%H:%M')
        self.mFrame = Frame()
        self.mFrame.pack(side=TOP,fill=X)
        
        self.watch = Label(self.mFrame,text=self.time2, font=('times',15,'bold'))
        self.watch.pack()
        
        self.changeLabel()
        
 
    
    #switch push for help
     # Run until someone presses enter
    #GPIO.cleanup() # Clean up

    
        

    def changeLabel(self):
        
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="12345678",
            database="robot_for_elderly"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT time,annotation FROM timealert")
        myresult = mycursor.fetchall()
        
        i=0
        for x in myresult:
            if self.time2 == x[0]:
                time.sleep(1)
                self.AlertBox(myresult,i)
            i+=1
            
        self.time2 = time.strftime('%H:%M:%S')
        self.watch.configure(text=self.time2)
        self.mFrame.after(200,self.changeLabel)
            
    
        
            
    def AlertBox(self,detail,noun):
        pygame.mixer.init()
        pygame.mixer.music.load("medictime.mp3")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue
        MsgBox = tk.messagebox.askquestion ('Medication Time !',detail[noun],icon = "warning")
        
        if MsgBox == 'yes':
            
            print("EAT")
            DIR = 20 #tit tang
            STEP = 21 # 
            CW = 0
            CCW = 0
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BOARD)
            GPIO.setup(38,GPIO.OUT)
            GPIO.setup(40,GPIO.OUT)
            GPIO.output(38,CW)
            GPIO.setup(11,GPIO.OUT)
            servo1 = GPIO.PWM(11,25)
            servo1.start(0)
            
            try:
                sleep(1)
                for x in range(0,6):
                    servo1.ChangeDutyCycle(x)
                    time.sleep(0.1)
                    print(x)

                servo1.ChangeDutyCycle(1)
                time.sleep(0.5)
                servo1.start(0)
                servo1.stop()
                
                sleep(1)
                
                time.sleep(3)
                sample= readCount()
                flag=0
                while 1:
                    count= readCount()
                    w = 0
                    w=(sample-count)/106 #106
                    #print (count,"count")
                    #print (sample,"sample")
                    #print (int(w),"g")
                    break
                print (int(w),"g")
                if w < 2400  :
                    GPIO.output(38,0) #0kuun 1long
                    for x in range(4500):
                        GPIO.output(40,GPIO.HIGH)
                        sleep(.00002)
                        GPIO.output(40,GPIO.LOW)
                        sleep(.00002)
                        
                    sleep(1)
                    GPIO.output(38,1) #0kuun 1long
                    for x in range(4500):
                        GPIO.output(40,GPIO.HIGH)
                        sleep(.00002)
                        GPIO.output(40,GPIO.LOW)
                        sleep(.00002)
            
                    GPIO.cleanup()
                    print ("Goodbye")
                    ref = db.reference("Medication")
                    ref.push(self.time2)
                    self.history()
                else:
                    print ("else")
                    ref = db.reference("Machine Accident")
                    ref.push(self.time2)
                    print ("fin")
                    
            except KeyboardInterrupt:
                print ("X")
                GPIO.cleanup()
            #self.history()
        

        else:
            tk.messagebox.showinfo('Return','You will now return to  thr application screen')
       
    def history(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="12345678",
            database="robot_for_elderly"
            )
        
        mycursor = mydb.cursor()
        detail ="testrrrr"
        time = self.time2
        sql = "INSERT INTO `history` (`time`,`detail`) VALUES(%s,%s)"
        mycursor.execute(sql,(time,detail))
        mydb.commit()
        #cred = credentials.Certificate('./video-meeting-5fccc-firebase-adminsdk-f4zug-907c6ea812.json')
        #firebase_admin.initialize_app(cred, {'databaseURL': 'https://video-meeting-5fccc-default-rtdb.firebaseio.com/'})
        #ref = db.reference("Medication")
        #ref.push(self.time2)
        #cred2 = credentials.Certificate('./project-d0cc1-firebase-adminsdk-m2qwb-362e4e1cfd.json')
        #firebase_admin.initialize_app(cred2, {'databaseURL': 'https://project-d0cc1.firebaseio.com/'})
        #ref2 = db.reference("test")
        #ref2.push({"test"})
        print ("insert complete")
        
        
    
    
    def fallalert(self):
        
        print("Fall Detection")
        print ("sw ==> " + str(GPIO.input(37)))
        pygame.mixer.init()
        pygame.mixer.music.load("alert.mp3")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue
        
        tk.messagebox.showinfo('Alert !!','Fall Detection',icon = "warning")
        ref = db.reference("Falldetect")
        ref.push("help me!")
        
        
        
    GPIO.setwarnings(False) # Ignore warning for now
    GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
    GPIO.setup(37, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # Set pin 10 to be an input pin and set initial value to be pulled low (off)
    if GPIO.input(37) == GPIO.HIGH:
        print("Help Me !")
        time.sleep(2)
        GPIO.add_event_detect(37,GPIO.RISING,callback=fallalert)
    
    def heartalert(self):
        #ser = serial.Serial('/dev/ttyUSB0',9600)
        #read_serial_falldetec=ser.readline()
        #print(read_serial_falldetec)
        ref = db.reference("Accident")
        ref.push("help me!")
        print("Hlep me !!!!")#
        print ("sw2 ==> " + str(GPIO.input(13)))
        pygame.mixer.init()
        pygame.mixer.music.load("alert.mp3")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue
        tk.messagebox.showinfo('Alert !','Hlep me !!!!',icon = "warning")
    GPIO.setwarnings(False) # Ignore warning for now
    GPIO.setmode(GPIO.BOARD)
    # Use physical pin numbering
    GPIO.setup(13, GPIO.IN)
    
    GPIO.add_event_detect(13,GPIO.RISING,callback=heartalert)
        

    def button_callback(self):
        ref = db.reference("Accident")
        ref.push("help me!")
        pygame.mixer.init()
        pygame.mixer.music.load("alert.mp3")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue
        
        print("Help Me")
        print ("sw ==> " + str(GPIO.input(35)))
        
        tk.messagebox.showinfo('Alert !!','Need Help',icon = "warning")
        
    GPIO.setwarnings(False) # Ignore warning for now
    GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
    GPIO.setup(35, GPIO.IN) # Set pin 10 to be an input pin and set initial value to be pulled low (off)
    if GPIO.input(35) == GPIO.LOW:
        print("Help Me !")
        time.sleep(2)
        GPIO.add_event_detect(35,GPIO.RISING,callback=button_callback) # Setup event on pin 10 rising edge
    
    #message = input("Press enter to quit\n\n")
    
    
        #--------------------------- 

class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")

        # the container is where we'll stack a bunch of frames
        # on top of each other, then the one we want visible
        # will be raised above the others
        container = tk.Frame(self)
        container.pack(side="bottom", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, PageOne, PageTwo, PageThree,PageFour,PageFive):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all of the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")
            self.show_frame("StartPage")
        

    def show_frame(self, page_name):
        '''Show a frame for the given page name'''
        frame = self.frames[page_name]
        frame.tkraise()
        
    


class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Welcome To Robot", font=controller.title_font)
        label.pack(side="top", fill="x", pady=30)

        button1 = tk.Button(self, text="Home",font=controller.title_font,command=lambda: controller.show_frame("PageOne"))
        button2 = tk.Button(self, text="Setting",font=controller.title_font,command=lambda: controller.show_frame("PageFour"))
        button1.place(x=250,y=400)
        button2.place(x=850,y=400)

        img1 = Image.open("Add.png")
        render = ImageTk.PhotoImage(img1)
        imgadd = Label(self, image=render)
        imgadd.image = render
        imgadd.place(x=790, y=150)

        img2 = Image.open("user.png")
        render2 = ImageTk.PhotoImage(img2)
        imguser = Label(self, image=render2)
        imguser.image = render2
        imguser.place(x=190, y=150)

        
class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        call = Image.open("call.png")
        callrender = ImageTk.PhotoImage(call)
        imagecall = tk.Button(self,image=callrender,border=0,command=lambda:webbrowser.open_new("https://meet.jit.si/test1150"))
        imagecall.image = callrender
        imagecall.place(x=60,y=165)

        time = Image.open("time.png")
        timerender = ImageTk.PhotoImage(time)
        imagetime = tk.Button(self,image=timerender,border=0,command=lambda: controller.show_frame("PageFour"))
        imagetime.image = timerender
        imagetime.place(x=535,y=165)

        list = Image.open("list.png")
        listrender = ImageTk.PhotoImage(list)
        imagelist = tk.Button(self,image=listrender,border=0,command=lambda: controller.show_frame("PageFive"))
        imagelist.image = listrender
        imagelist.place(x=935,y=165)
        
    def call():
        webborwser.open_new("www.google.com")
        
        
        
    

class PageTwo(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="User Setting Connect Device", font=controller.title_font)
        label.pack(side="top", fill="x", pady=30)
        tel = tk.Label(self, text="Tel:", font=controller.title_font)
        tel.place(x=130,y=150)
        inputtel = tk.Entry(self,width=30,font=controller.title_font)
        inputtel.place(x=200,y=150)
        button = tk.Button(self, text="Next Step 2",font=controller.title_font,command=lambda: controller.show_frame("PageThree"))
        button.place(x=600,y=265)

class PageThree(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="User Setting Connect Device Token", font=controller.title_font)
        label.pack(side="top", fill="x", pady=30)
        token = tk.Label(self, text="Token:", font=controller.title_font)
        token.place(x=100,y=150)
        inputtel = tk.Entry(self,width=30,font=controller.title_font)
        inputtel.place(x=200,y=150)
        button = tk.Button(self, text="Next Step 3",font=controller.title_font,command=lambda: controller.show_frame("PageFour"))
        button.place(x=600,y=265)
        button2 = tk.Button(self, text="Back Step 2",font=controller.title_font,command=lambda: controller.show_frame("PageOne"))
        button2.place(x=35,y=265)

class PageFour(tk.Frame):
    def __init__(self, parent, controller):
            tk.Frame.__init__(self, parent)
            self.controller = controller
            label = tk.Label(self, text="User Setting Time Alert", font=controller.title_font)
            label.pack(side="top", fill="x", pady=30)
                
            self.refresh()  
               
            button9 = tk.Button(self,text="Insert",command=lambda: self.insert())
            button9.place(x=900,y=199)
            button9 = tk.Button(self,text="Delete",command=lambda: self.delete())
            button9.place(x=1000,y=199)
            button = tk.Button(self, text="Start Program",font=controller.title_font,command=lambda: controller.show_frame("PageOne"))
            button.place(x=900,y=265)
            button8 = tk.Button(self,text="Refresh",command=lambda: self.refresh())
            button8.place(x=220,y=199)
            
    
    
    def refresh(self):
            mydb = mysql.connector.connect(
              host="localhost",
              user="root",
              passwd="12345678",
              database="robot_for_elderly"
            )
            mycursor = mydb.cursor()
            mycursor.execute("SELECT time FROM timealert")
            myresult = mycursor.fetchall()
            listbox = Listbox(self, font=('Helvetica','18',"bold","italic"))
            listbox.place(x=470,y=98)
            listbox.insert(1, "Time Alert")
            for x in myresult:
                listbox.insert(END, x)  
            
    def insert(self):
        MsgBox = tk.messagebox.askquestion ('Insert Time',"Confirm to insert time ?",icon = "warning")
        if MsgBox == 'yes':
            ser = serial.Serial('/dev/ttyACM0',9600)
            mydb = mysql.connector.connect(
              host="localhost",
              user="root",
              passwd="12345678",
              database="robot_for_elderly"
            )
            while True:
                read_serial=ser.readline()
                mycursor = mydb.cursor()
                print(read_serial)
                time = read_serial[:8]
                anno =" "
                sql = "INSERT INTO `timealert` (`time`,`annotation`) VALUES(%s,%s)"
                mycursor.execute(sql,(time,anno))
                mydb.commit()
                tk.messagebox.showinfo('Return','Insert Complete')
                break
        else:
            tk.messagebox.showinfo('Return','Cancle')
            
    def delete(self):
        MsgBox = tk.messagebox.askquestion ('Delete Time',"Confirm to delete time ?",icon = "warning")
        if MsgBox == 'yes':
            ser = serial.Serial('/dev/ttyACM0',9600)
            mydb = mysql.connector.connect(
              host="localhost",
              user="root",
              passwd="12345678",
              database="robot_for_elderly"
            )
            while True:
                read_serial=ser.readline()
                mycursor = mydb.cursor()
                print(read_serial)
                time = (read_serial[:8],)
                anno ="."
                sql = "DELETE FROM `timealert` WHERE `time` = %s"
                mycursor.execute(sql, time)
                mydb.commit()
                tk.messagebox.showinfo('Return','Delete Complete')
                break
        else:
            tk.messagebox.showinfo('Return','Cancle')
            

class PageFive(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Medication History", font=controller.title_font)
        label.pack(side="top", fill="x", pady=30)
        self.showhistory()
        Button(self, text='Submit',command=lambda: controller.show_frame("PageOne"),width=20,bg='brown',fg='white').place(x=600,y=380)
        Button(self, text='Refresh',command=lambda: self.showhistory(),width=20,bg='brown',fg='white').place(x=400,y=380)
        
    def showhistory(self):
            mydb = mysql.connector.connect(
              host="localhost",
              user="root",
              passwd="12345678",
              database="robot_for_elderly"
            )
            mycursor = mydb.cursor()
            mycursor.execute("SELECT time,detail FROM history")
            myresult = mycursor.fetchall()
            listbox = Listbox(self, font=('Helvetica','18',"bold","italic"))
            listbox.place(x=470,y=80)
            listbox.insert(1, "History")
            for x in myresult:
                listbox.insert(END, x)
        


if __name__ == "__main__":
    app = SampleApp()
    app.title("Robot for Elderly")
    objl=Clock()
    app.geometry('1280x720')
    app.mainloop()
    alert=Alert()




